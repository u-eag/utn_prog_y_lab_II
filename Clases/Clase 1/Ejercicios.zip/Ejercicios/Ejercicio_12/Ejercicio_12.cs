﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12
{
    class Ejercicio_12
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 12";

            /* Realizar un programa que sume números enteros hasta que el usuario lo determine, por medio de
               un mensaje "¿Continuar? (S/N)".
               En el método estático ValidaS_N(char c) de la clase ValidarRespuesta, se validará el ingreso de
               opciones.
               El método devolverá un valor de tipo booleano, TRUE si se ingresó una 'S' y FALSE si se ingresó
               cualquier otro valor. */

            int num;
            string aux;
            bool continuar = true;

            Console.WriteLine("A continuación podrá ingresar números enteros hasta que ud. lo desee.\n");

            do
            {
                Console.Write("Ingrese un número entero: ");
                aux = Console.ReadLine();



                Console.Write("¿Desea continuar ingresando números? S/N: ");


            } while (continuar);
        }
    }
}
