﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    public class Producto
    {
        private string codigoDeBarra;
        private string marca;
        private float precio;

        public static explicit operator String(Producto p)
        {
            return p.codigoDeBarra;
        }

        public string GetMarca()
        {
            return this.marca;
        }

        public float GetPrecio()
        {
            return this.precio;
        }

        public static string MostrarProducto(Producto p)
        {
            string mostrarProd = string.Format("\nMarca: {0} \nPrecio: ${1} \nCódigo de barra: {2}\n",
                                                p.GetMarca(), p.GetPrecio(), p.codigoDeBarra);

            return mostrarProd; 
        }

        public static bool operator == (Producto p1, Producto p2)
        {
            bool retorno = false;

            if (p1.GetMarca() == p2.GetMarca()
                && p1.codigoDeBarra == p2.codigoDeBarra)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator != (Producto p1, Producto p2)
        {
            return !(p1 == p2);
        }

        public static bool operator == (Producto p, string marca)
        {
            if ( p.GetMarca() == marca )
            {
                return true;
            }

            return false;
        }

        public static bool operator != (Producto p, string marca)
        {
            return !(p.GetMarca() == marca);
        }
    }
}
