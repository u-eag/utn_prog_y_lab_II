﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    public class Estante
    {
        private Producto[] productos; // array de productos
        private int ubicacionEstante;

        private Estante (int capacidad) // capacidad: cantidad de valores
        {
            this.productos = new Producto[capacidad];
        }

        public Estante (int capacidad, int ubicacion)
        {
            Estante estante = new Estante(capacidad);

            estante.ubicacionEstante = ubicacion;
        }

        public Producto[] GetProductos()
        {
            return this.productos;
        }

        public static string MostrarEstante(Estante e)
        {
            string listado = string.Format("Ubicación{0}", e.ubicacionEstante);
            
            // recorro el array de productos y llamo al método MostrarProductos de la clase Producto:
            for (int i=0; i<e.GetProductos().Length; i++)
            {
                listado += Producto.MostrarProducto(e.GetProductos()[i]);
            }

            return listado;
        }
    }
}
