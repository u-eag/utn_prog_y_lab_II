﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11
{
    class Ejercicio_11
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 11";

            /*  Realizar una clase llamada Validacion que posea un método estático llamado Validar, que posea la
                siguiente firma: bool Validar(int valor, int min, int max):
                a. valor: dato a validar
                b. min y max: rango en el cual deberá estar la variable valor.
                Pedir al usuario que ingrese 10 números enteros. Validar con el método desarrollado
                anteriormente que esten dentro del rango -100 y 100.
                Terminado el ingreso mostrar el valor mínimo, el valor máximo y el promedio.
                Nota: Utilizar variables escalares, NO utilizar vectores */

            int num;
            string aux;
            int i = 0;
            int minimo = int.MaxValue;
            int maximo = int.MinValue;
            int acumulador = 0;
            float promedio;

            Console.WriteLine("A continuación deberá ingresar 10 números enteros entre -100 y 100");

            do
            {
                Console.Write("Ingrese el número {0} de 10: ", i+1);

                aux = Console.ReadLine();

                if (int.TryParse(aux, out num) && Validacion.Validar(num, -100, 100))
                {
                    i++;

                    if (num < minimo)
                    {
                        minimo = num;
                    }

                    if (num > maximo)
                    {
                        maximo = num;
                    }

                    acumulador += num;
                }
                else
                {
                    Console.WriteLine("Número inválido. El número debe ser un entero entre -100 y 100.");
                }

            } while (i < 10);

            promedio = (float)acumulador / i;

            Console.WriteLine("El valor mínimo es: {0}", minimo);
            Console.WriteLine("El valor máximo es: {0}", maximo);
            Console.WriteLine("El valor promedio es: {0}", promedio);

            Console.ReadKey();
        }
    }
}
