﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12
{
    class Ejercicio_12
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 12";

            /* Realizar un programa que sume números enteros hasta que el usuario lo determine, por medio de
               un mensaje "¿Continuar? (S/N)".
               En el método estático ValidaS_N(char c) de la clase ValidarRespuesta, se validará el ingreso de
               opciones.
               El método devolverá un valor de tipo booleano, TRUE si se ingresó una 'S' y FALSE si se ingresó
               cualquier otro valor. */

            int num;
            string aux;
            ConsoleKeyInfo rta;
            int acumulador = 0;

            Console.WriteLine("A continuación podrá ingresar números enteros hasta que ud. lo desee.");

            do
            {
                Console.Write("\nIngrese un número entero: ");
                aux = Console.ReadLine();

                if (int.TryParse(aux, out num))
                {
                    acumulador += num;
                }
                else
                {
                    Console.WriteLine("Ingreso inválido. El número debe ser entero.");
                }

                Console.Write("¿Desea continuar ingresando números? S/N: ");
                rta = Console.ReadKey();
                // Otra opción: aux = Console.ReadLine();
                // char.TryParse(aux, out rta);
            } while (ValidarRespuesta.ValidarS_N(rta.KeyChar)); // KeyChar es el caracter

            Console.WriteLine("\nLos números ingresados suman: {0}", acumulador);

            Console.ReadKey();

        }
    }
}
