﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Alumno
    {
        private byte nota1; // int > short: del -32.768 al 32.767 > byte: del 0 al 255
        private byte nota2;
        private float notaFinal;
        public string apellido;
        public int legajo;
        public string nombre;

        public void CacularFinal()
        {
            Random notaFinal = new Random(); // invoco al constructor
            if (this.nota1 >= 4 && this.nota2 >= 4)
            {
                this.notaFinal = notaFinal.Next(1, 10); // la nota final va a ser un valor random entre 1 y 10
            }
            else
            {
                this.notaFinal = -1;
            }
        }

        /// <summary>
        /// Este método ingresa las notas 1 y 2
        /// </summary>
        /// <param name="notaUno"></param>
        /// <param name="notaDos"></param>
        public void Estudiar(byte notaUno, byte notaDos)
        {

        }
    }
}
