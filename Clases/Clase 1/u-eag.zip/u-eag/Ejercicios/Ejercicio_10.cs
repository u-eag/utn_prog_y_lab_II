﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicios
{
    class Ejercicio_10
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 10";

            /* Partiendo de la base del ejercicio anterior, se pide realizar un programa que imprima por pantalla
                una pirámide como la siguiente:
                *
                ***
                *****
                *******
                *********
                Nota: Utilizar estructuras repetitivas y selectivas.            */

            int altura;
            string aux;
            int i = 0;
            string asterisco = "*";
            string espacioStr = string.Empty; // ""

            Console.Write("Ingrese la altura de la pirámide: ");

            do
            {
                aux = Console.ReadLine();

                if (int.TryParse(aux, out altura))
                {
                    i++;
                }
                else
                {
                    Console.Write("Altura inválida. Reingrese la altura: ");
                }

            } while (i < 1);

            // convierto los espacios a string:
            for (int j = 0; j < altura-1; j++) // con altura-1 la pirámide queda pegada al borde
            {
                espacioStr += " ";
            }

            for (i = 1; i <= altura; i++)
            {
                Console.WriteLine("{0}{1}", espacioStr, asterisco);
                asterisco += "**";
                
                // al string de espacios le resto espacios (de a uno):
                if (espacioStr.Length > 0) // porque en el último piso no va a haber espacio para eliminar
                {
                    espacioStr = espacioStr.Substring(1); // empieza a leer desde el 2do espacio
                }
            }
            Console.ReadKey();
        }
    }
}
